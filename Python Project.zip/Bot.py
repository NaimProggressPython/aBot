import os
import subprocess
import tkinter as tk
from tkinter import messagebox  # Добавьте этот импорт

class MyApplication:
    def __init__(self, root):
        self.root = root
        self.root.title("Aternos 24/7")

        self.start_button = tk.Button(root, text="Старт", command=self.start_function)
        self.start_button.pack(pady=10)

        self.stop_button = tk.Button(root, text="Стоп", command=self.stop_function)
        self.stop_button.pack(pady=10)

    def start_function(self):
        # Ваш код для обработки нажатия кнопки "Старт" должен быть здесь
        # Например, открытие веб-страницы с вашим JavaScript-кодом
        self.javascript_file_path = "E:/Python Project/1.js"
        self.process = subprocess.Popen(['node', self.javascript_file_path])

    def stop_function(self):
        # Ваш код для обработки нажатия кнопки "Стоп" должен быть здесь
        # Например, остановка процесса и вывод сообщения
        if hasattr(self, 'process') and self.process.poll() is None:
            self.process.terminate()
            messagebox.showinfo("Информация", "Бот отключен")

if __name__ == "__main__":
    root = tk.Tk()
    app = MyApplication(root)
    root.mainloop()
