const mineflayer = require('mineflayer');
const fs = require('fs');
const ini = require('ini');

// Парсим содержимое файла config.ini
const configIni = ini.parse(fs.readFileSync('config.ini', 'utf-8'));

// Задаем переменные, используя значения из файла config.ini или значения по умолчанию
const botName = configIni.BotConfig.botName || 'ВашБот';
const serverIp = configIni.BotConfig.serverIp || 'АйпиСервера';
const serverPort = configIni.BotConfig.serverPort || 25565;

// Создаем бота
const bot = mineflayer.createBot({
  username: botName,
  host: serverIp,
  port: serverPort,
});

// Обработчик события "spawn", вызывается, когда бот успешно заходит на сервер
bot.on('spawn', () => {
  console.log(`${bot.username} зашел на сервер.`);
});

// Обработчик события "chat", вызывается, когда кто-то отправляет сообщение в чат
bot.on('chat', (username, message) => {
  if (username !== bot.username) {
    // Отвечаем на сообщение, если оно не от бота
    bot.chat(`Привет, ${username}!`);
  }
});

// Обработчик события "kicked", вызывается, когда бот был выкинут с сервера
bot.on('kicked', (reason, loggedIn) => {
  console.log(`Бот был выкинут с сервера: ${reason}`);
});

// Обработчик события "error", вызывается, когда происходит ошибка
bot.on('error', (err) => {
  console.error('Произошла ошибка:');
  console.error(err);
});

// Останавливаем бот при получении сигнала завершения работы (Ctrl+C)
process.on('SIGINT', () => {
  console.log('Остановка бота...');
  bot.end();
});

// Оставляем бота в работе, чтобы он мог просто стоять
