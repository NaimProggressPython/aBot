const mineflayer = require('mineflayer');
const dotenv = require('dotenv');
const fs = require('fs');
const ini = require('ini');  // Включите эту строку только один раз

// Загружаем переменные окружения из файла .env
dotenv.config();

// Парсим содержимое файла config.ini
const configIni = ini.parse(fs.readFileSync('config.ini', 'utf-8'));

// Задаем переменные, используя значения из файла config.ini или значения по умолчанию
let botName = process.env.BOT_NAME || configIni.botName || '3jask';
let serverIp = process.env.SERVER_IP || configIni.serverIp || 'Tryhardiks.aternos.me';
let serverPort = process.env.SERVER_PORT || configIni.serverPort || 46136;

// Ваш код для запуска бота и другой логики
// ...

// Создаем бота с текущими значениями переменных
const bot = mineflayer.createBot({
  username: botName,
  host: serverIp,
  port: serverPort,
});

// Ваш остальной код обработки событий и логики
// ...

// Обновляем значения переменных при изменении .env или config.ini
setInterval(() => {
  // Перечитываем переменные окружения из файла .env
  dotenv.config();

  bot.on('error', (err) => {
  console.error('Ошибка бота:');
  console.error(err);
});


bot.on('end', () => {
  console.log('Соединение закрыто. Повторное подключение...');
  // Реализуйте здесь вашу логику повторного подключения
});


  // Перечитываем значения из файла config.ini
  const updatedConfigIni = ini.parse(fs.readFileSync('config.ini', 'utf-8'));

  // Обновляем переменные
  botName = process.env.BOT_NAME || updatedConfigIni.botName || '3jask';
  serverIp = process.env.SERVER_IP || updatedConfigIni.serverIp || 'Tryhardiks.aternos.me';
  serverPort = process.env.SERVER_PORT || updatedConfigIni.serverPort || 46136;

  console.log(`Updated Bot Name: ${botName}`);
  console.log(`Updated Server IP: ${serverIp}`);
  console.log(`Updated Server Port: ${serverPort}`);

  // Обновляем бота с новыми значениями
  bot.username = botName;
  bot.host = serverIp;
  bot.port = serverPort;
}, 5000);  // Обновляем каждые 5 секунд (можно изменить по необходимости)
